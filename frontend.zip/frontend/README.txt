MySQL server is needed for the backend, this runs the database, the provided script is used to create the database, and can be run for example in mysql workbench.
The front end uses a python script.  Python 2.7 was used.  The mysql.connector library from MySQL was used to connect the database to the front end, This can be installed using pip, which is installed with recent python installs.
Once the database is running and python/mySQL connector are installed, go to the folder containing the python scripts and compile the main.py script to start using the program
To download mySQL server/workbench: https://dev.mysql.com/downloads/
To download Python: https://www.python.org/downloads/ 